<nav>
    <div class="nav-wrapper" style="background-color: #b9005f!important;">
        <a href="#!" class="brand-logo"><i class="far fa-comments" style="font-size: 90%"></i>Lista de Contatos</a>
        <a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
        <ul class="right hide-on-med-and-down">
            <li><a href="sass.html">Gerenciar Listas</a></li>
            <li><a href="badges.html">Relatórios</a></li>
            <li><?php if(Route::has('login')): ?>
                    <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
                        <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e(url('/home')); ?>" class="text-sm text-gray-700 underline">Início</a>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="text-sm text-gray-700 underline">Login</a>

                            <?php if(Route::has('register')): ?>
                                <a href="<?php echo e(route('register')); ?>" class="ml-4 text-sm text-gray-700 underline">Cadastro</a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?></li>
        </ul>
    </div>
</nav>

<ul class="sidenav" id="mobile-demo">
    <li><a href="sass.html">Gerenciar Listas</a></li>
    <li><a href="badges.html">Relatórios</a></li>
</ul>

<?php /**PATH C:\xampp\htdocs\ContactList_Talkip\Contactlist_App\resources\views//base_templates/navbar.blade.php ENDPATH**/ ?>
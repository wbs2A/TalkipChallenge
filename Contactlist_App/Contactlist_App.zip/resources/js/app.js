require('./bootstrap');
$(document).ready(function(){
    $('.sidenav').sidenav();
});
